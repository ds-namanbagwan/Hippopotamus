import{j as t,F as o}from"./jsx-runtime-5295a48b.js";const g=({title:l,_site:r,global:s,children:a})=>t(o,{children:a});export{g as P};
