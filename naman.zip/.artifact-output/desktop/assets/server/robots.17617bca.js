import{s as t}from"../static/global-239da612.js";const o={name:"robots"},e=()=>"robots.txt",s=r=>`Sitemap: ${t}/sitemap.xml
  User-agent: /`;export{o as config,e as getPath,s as render};
