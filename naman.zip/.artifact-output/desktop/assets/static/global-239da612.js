const s="https://main-usually--assistant--coyote-sbx-pgsdemo-com.sbx.preview.pagescdn.com/",t="https://a.mktgcdn.com/p-sandbox/JPBowt854rpiZHUkXeMpcoAAma6yNy_ph09d3CDaFxY/304x154.png",a="AIzaSyDZNQlSlEIkFAct5VzUtsP4dSbvOr2bE18",o=new Intl.DisplayNames(["en"],{type:"region"}),n=!0,e=!0,c={cid:"",cv:"1"},i=51.5095146286,l=-.1244828354,g='<svg xmlns="http://www.w3.org/2000/svg" width="20.953" height="20.953" viewBox="0 0 20.953 20.953"><path id="Icon_ionic-md-close" data-name="Icon ionic-md-close" d="M28.477,9.619l-2.1-2.1L18,15.9,9.619,7.523l-2.1,2.1L15.9,18,7.523,26.381l2.1,2.1L18,20.1l8.381,8.381,2.1-2.1L20.1,18Z" transform="translate(-7.523 -7.523)" fill="#B1B1B1"></path></svg>',r=`<svg
xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" >
<path
  
  d="M8.5,5.955A2.545,2.545,0,1,0,11.045,8.5,2.545,2.545,0,0,0,8.5,5.955Zm5.689,1.909A5.724,5.724,0,0,0,9.136,2.811V1.5H7.864V2.811A5.724,5.724,0,0,0,2.811,7.864H1.5V9.136H2.811a5.724,5.724,0,0,0,5.053,5.053V15.5H9.136V14.189a5.724,5.724,0,0,0,5.053-5.053H15.5V7.864ZM8.5,12.955A4.455,4.455,0,1,1,12.955,8.5,4.451,4.451,0,0,1,8.5,12.955Z"
  transform="translate(-1.5 -1.5)"
  fill="#fff"
/>
</svg>`;export{n as A,g as C,r as U,e as a,i as b,c,l as d,t as f,a as g,o as r,s};
