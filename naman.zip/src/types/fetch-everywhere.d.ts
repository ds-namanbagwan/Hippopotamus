declare module "fetch-everywhere";
